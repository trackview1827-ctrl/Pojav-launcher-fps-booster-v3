package com.pojavspoofer.mixin;

import com.pojavspoofer.PojavSpooferMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * System.getProperty() çağrılarını yakalar.
 * Modlar os.name, os.arch gibi bilgileri okuyunca sahte PC verisi döndürür.
 */
@Mixin(value = System.class, remap = false)
public abstract class SystemPropertyMixin {

    @Inject(
        method = "getProperty(Ljava/lang/String;)Ljava/lang/String;",
        at = @At("HEAD"),
        cancellable = true,
        remap = false
    )
    private static void spoofGetProperty(String key, CallbackInfoReturnable<String> cir) {
        String spoofed = getSpoofedValue(key);
        if (spoofed != null) {
            PojavSpooferMod.LOGGER.debug("[PojavSpoofer] Engellendi: System.getProperty({}) => {}", key, spoofed);
            cir.setReturnValue(spoofed);
        }
    }

    @Inject(
        method = "getProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;",
        at = @At("HEAD"),
        cancellable = true,
        remap = false
    )
    private static void spoofGetPropertyDefault(String key, String def, CallbackInfoReturnable<String> cir) {
        String spoofed = getSpoofedValue(key);
        if (spoofed != null) {
            PojavSpooferMod.LOGGER.debug("[PojavSpoofer] Engellendi: System.getProperty({}, {}) => {}", key, def, spoofed);
            cir.setReturnValue(spoofed);
        }
    }

    /**
     * Hangi property'nin sahte değer döndüreceğini belirler.
     * null dönerse orijinal değer kullanılır (müdahale yok).
     */
    private static String getSpoofedValue(String key) {
        if (key == null) return null;
        switch (key) {
            // İşletim sistemi tespiti
            case "os.name":    return PojavSpooferMod.FAKE_OS_NAME;
            case "os.version": return PojavSpooferMod.FAKE_OS_VERSION;
            case "os.arch":    return PojavSpooferMod.FAKE_OS_ARCH;

            // CPU çekirdek sayısı (bazı modlar bunu da kontrol eder)
            case "java.vm.name":    return "OpenJDK 64-Bit Server VM";
            case "java.vm.vendor":  return "Oracle Corporation";

            // Android'e özel property'ler - boş döndür (varlığını gizle)
            case "ro.build.version.sdk":
            case "ro.product.model":
            case "ro.product.brand":
            case "ro.product.manufacturer":
            case "android.os.Build.VERSION.SDK_INT":
                return "";

            default: return null; // Diğer her şeye dokunma
        }
    }
}
