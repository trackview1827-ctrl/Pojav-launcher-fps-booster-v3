package com.pojavspoofer.mixin;

import com.pojavspoofer.PojavSpooferMod;
import net.minecraft.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Minecraft'ın kendi OS tespitini (Util.getOperatingSystem) yakalar.
 * Modlar bunu kullanarak WINDOWS / LINUX / UNKNOWN ayrımı yapar.
 * Pojav'da normalde UNKNOWN veya LINUX döner → modlar bunu görünce kısıtlar.
 * Biz WINDOWS döndürürüz.
 */
@Mixin(Util.class)
public abstract class OsMixin {

    @Inject(
        method = "getOperatingSystem",
        at = @At("HEAD"),
        cancellable = true
    )
    private static void spoofOperatingSystem(CallbackInfoReturnable<Util.OperatingSystem> cir) {
        // Gerçek değeri al
        Util.OperatingSystem real = Util.getOperatingSystem();

        // Eğer Windows değilse → Windows gibi davran
        if (real != Util.OperatingSystem.WINDOWS) {
            PojavSpooferMod.LOGGER.debug(
                "[PojavSpoofer] getOperatingSystem(): {} -> WINDOWS (sahte)",
                real
            );
            cir.setReturnValue(Util.OperatingSystem.WINDOWS);
        }
    }
}
