package com.pojavspoofer.mixin;

import com.pojavspoofer.PojavSpooferMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Runtime.availableProcessors() çağrısını yakalar.
 * Bazı modlar CPU çekirdek sayısını okuyarak mobil cihaz tespiti yapar
 * (örn: 4 çekirdek = mobil, 8+ çekirdek = PC mantığı).
 * Sahte 8 çekirdek döndürür.
 */
@Mixin(value = Runtime.class, remap = false)
public abstract class RuntimeMixin {

    @Inject(
        method = "availableProcessors",
        at = @At("HEAD"),
        cancellable = true,
        remap = false
    )
    private void spoofAvailableProcessors(CallbackInfoReturnable<Integer> cir) {
        int realCores = Runtime.getRuntime().availableProcessors();
        int fakeCores = Integer.parseInt(PojavSpooferMod.FAKE_CPU_CORES);

        // Gerçek değer zaten yüksekse müdahale etme
        if (realCores < fakeCores) {
            PojavSpooferMod.LOGGER.debug(
                "[PojavSpoofer] availableProcessors(): {} -> {} (sahte)",
                realCores, fakeCores
            );
            cir.setReturnValue(fakeCores);
        }
    }
}
