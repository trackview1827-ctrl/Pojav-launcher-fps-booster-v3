package com.pojavspoofer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public class PojavSpooferMod implements ClientModInitializer {

    public static final String MOD_ID = "pojavspoofer";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Sahte PC bilgileri - modlar bunları okuyunca PC sanacak
    public static final String FAKE_OS_NAME    = "Windows 10";
    public static final String FAKE_OS_VERSION = "10.0";
    public static final String FAKE_OS_ARCH    = "amd64";
    public static final String FAKE_CPU_CORES  = "8";

    @Override
    public void onInitializeClient() {
        LOGGER.info("[PojavSpoofer] Yüklendi! Sistem bilgileri PC olarak gösteriliyor.");
        LOGGER.info("[PojavSpoofer] os.name    => {}", FAKE_OS_NAME);
        LOGGER.info("[PojavSpoofer] os.version => {}", FAKE_OS_VERSION);
        LOGGER.info("[PojavSpoofer] os.arch    => {}", FAKE_OS_ARCH);
        LOGGER.info("[PojavSpoofer] CPU çekirdek => {}", FAKE_CPU_CORES);
    }
}
