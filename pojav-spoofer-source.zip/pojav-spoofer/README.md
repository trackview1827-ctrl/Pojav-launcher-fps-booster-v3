# PojavSpoofer Modu

**Fabric 1.21.1** | Pojav Launcher için

## Ne Yapar?

Bazı modlar çalışırken sistemi sorgular:
- `System.getProperty("os.name")` → Android tespiti
- `Runtime.availableProcessors()` → Düşük çekirdek = mobil tespiti  
- `Util.getOperatingSystem()` → Minecraft'ın kendi OS kontrolü

Bu tespiti yapan modlar Pojav'da **kasıtlı FPS düşürür** veya özellikleri kısıtlar.

**PojavSpoofer** bu sorguları yakalar ve sahte PC bilgisi döndürür:

| Sorgu | Gerçek Değer | Sahte Değer |
|-------|-------------|-------------|
| `os.name` | Android / Linux | Windows 10 |
| `os.version` | (Android ver.) | 10.0 |
| `os.arch` | aarch64 | amd64 |
| `availableProcessors()` | 4-6 | 8 |
| `getOperatingSystem()` | UNKNOWN/LINUX | WINDOWS |
| Android özgü property'ler | değer | boş string |

---

## Derleme (PC'de)

### Gereksinimler
- Java 21 JDK
- Git

### Adımlar

```bash
# Projeyi klonla / klasöre gir
cd pojav-spoofer

# Gradle wrapper indir
gradle wrapper

# Derle
./gradlew build

# Çıktı: build/libs/pojav-spoofer-1.0.0.jar
```

---

## Kurulum (Pojav Launcher)

1. `pojav-spoofer-1.0.0.jar` dosyasını `.minecraft/mods/` klasörüne koy
2. Fabric Loader 0.15.11+ yüklü olsun
3. Oyunu başlat — logda şunu görmelisin:
   ```
   [PojavSpoofer] Yüklendi! Sistem bilgileri PC olarak gösteriliyor.
   ```

---

## Notlar

- Bu mod **Fabric API** gerektirir
- Sadece **istemci tarafı** çalışır, sunucuya gerekmez
- Hiçbir şeyi sunucuya göndermez, tamamen yerel çalışır
- Oyunun normal işleyişine zarar vermez
